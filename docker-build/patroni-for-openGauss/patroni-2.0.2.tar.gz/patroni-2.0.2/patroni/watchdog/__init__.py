from patroni.watchdog.base import WatchdogError, Watchdog
__all__ = ['WatchdogError', 'Watchdog']
